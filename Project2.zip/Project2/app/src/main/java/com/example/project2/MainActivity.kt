package com.example.project2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.view.View
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun calculateCost(view: View)
    {
        //grab expense value + convert to Int
        val editexpenses = findViewById<EditText>(R.id.expensesInput)
        val expensestext = editexpenses.text
        val expenses: Int = expensestext.toString().toInt()

        //grab income value + convert to Int
        val editincome = findViewById<EditText>(R.id.incomeInput)
        val incometext = editincome.text
        val income: Int = incometext.toString().toInt()

        //grab purchase value + convert to Int
        val editpurchases = findViewById<EditText>(R.id.purchaseInput)
        val purchasestext = editpurchases.text
        val purchases: Int = purchasestext.toString().toInt()

        //calculate cost + ability to purchase
        val leftover = income - expenses
        val canAfford = leftover - (purchases*2)
        if (canAfford < 0)
        {
            resultText.text = "You cannot afford that purchase."
        }else{
            resultText.text = "You can afford that!"
        }


    }
}
