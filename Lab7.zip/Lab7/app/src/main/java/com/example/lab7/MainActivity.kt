package com.example.lab7

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun sayGenerate(view: View){
        val madlibText = findViewById<TextView>(R.id.madlibTextbox)

        val editnoun = findViewById<EditText>(R.id.inputNoun)
        val noun = editnoun.text

        val editadj = findViewById<EditText>(R.id.inputAdj)
        val adj = editadj.text

        madlibText.setText("Hi, this is " + noun + " I would love to book \n" + "a room at your " + adj + " hotel!")

        val imageLaugh = findViewById<ImageView>(R.id.imageView)
        imageLaugh.setImageResource(R.drawable.laughing)
    }
}