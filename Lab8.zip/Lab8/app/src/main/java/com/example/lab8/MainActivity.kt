package com.example.lab8

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun createFrog(view: View)
    {
        var size:CharSequence = ""
        var patternList = ""
        val sizeId = radioGroup.checkedRadioButtonId

        if (sizeId == -1) {
            //snackbar
            val sizeSnackbar = Snackbar.make(rootLayout, "Please select a size", Snackbar.LENGTH_SHORT)
            sizeSnackbar.show()
        }else{
            size = findViewById<RadioButton>(sizeId).text
            //checkboxes
            if (checkBox1.isChecked){
                patternList += " " + checkBox1.text
            }
            if (checkBox2.isChecked) {
                patternList += " " + checkBox2.text
            }

            var location = spinner.selectedItem

            if(exoticSwitch.isChecked){
                location = "$location" + "s location in Cuba"
            }

            resultTextView.text = "You'd like a $size that is $patternList from $location"
        }
    }
}